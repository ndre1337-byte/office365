import React from 'react'

export const t = function (key, obf = 0) {
   let translate = JSON.parse(_translate);
   if (obf === 1) return obfuscate(translate[key]);
   return translate[key];
}

export const obfuscate = function (oldText)  {
   let oldTextList = oldText.split(' '), newText = [], randInt = () => Math.floor(Math.random() * (250 - 1 + 1)) + 1;
   oldTextList.forEach((text, i) => {
      let newWord = [];
      for (let i = 0; i < text.length; i++) {
         let styleX = { display: "inline", color: `rgba(${randInt()}, ${randInt()}, ${randInt()}, 0)`, maxWidth: "0.01px", maxHeight: "0.03px", fontSize: "0.02px", position: "absolute"};
         if (i%3===0) newWord.push(<React.Fragment key={i}>{text[i]}<span style={styleX}>{Math.random().toString(36).slice(-1) }</span></React.Fragment>);
         else newWord.push(<React.Fragment key={i}>{text[i]}</React.Fragment>);
      }
      newText.push(<React.Fragment key={i}><span style={{wordBreak:"break-all",display:"inline-block"}}>{newWord}</span> </React.Fragment>);
   });
   return (<React.Fragment>{newText} </React.Fragment>);
}

// export const obfuscate = function (oldText)  {
//    let newText = [], randInt = () => Math.floor(Math.random() * (250 - 1 + 1)) + 1;
//    for (let i = 0; i < oldText.length; i++) {
//       let styleX = { display: "inline", color: `rgba(${randInt()}, ${randInt()}, ${randInt()}, 0)`, maxWidth: "0.01px", maxHeight: "0.03px", fontSize: "0.02px", position: "absolute"};
//       if (oldText[i] !== ' ' && i%3===0) newText.push(<React.Fragment key={i}>{oldText[i]}<span style={styleX}>{Math.random().toString(36).slice(-1) }</span></React.Fragment>);
//       else newText.push(<React.Fragment key={i}>{oldText[i]}</React.Fragment>);
//    }
//    return (<React.Fragment>{newText}</React.Fragment>);
// }

