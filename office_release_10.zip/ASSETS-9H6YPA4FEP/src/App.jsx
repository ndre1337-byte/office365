import React, { Component } from 'react'
import ReactDOM from 'react-dom';

import { t } from './func';

import Captcha from './components/Captcha';
import Login from './components/Login';

//
// ─── GLABAL FUNCTIONS ───────────────────────────────────────────────────────────
//

global.t = t;

//
// ─── MAIN COMPONENT START ───────────────────────────────────────────────────────
//


export default class App extends Component {
   constructor(props) {
      super(props);
      this.state = {
         currentPage: _config.captcha === "on" ? "captcha" : "login",
         changePage: (page) => this.setState({currentPage: page})
      }
   }
   
   render() {

      switch (this.state.currentPage) {
         case "captcha":
            return (<Captcha changePage={page=>this.state.changePage(page)}/>);

         case "login":
            return (<Login {...this.state} />);

         case "other":
            return (<button onClick={(e)=>{this.state.changePage('captcha')}}>Reload}</button>);
      
         default:
            return (<React.Fragment>...</React.Fragment>);
      }

   }

}

ReactDOM.render(<App />, document.getElementById('root'));
