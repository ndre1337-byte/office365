import React, { Component } from 'react'
import Recaptcha from 'react-recaptcha'
import { StyleSheet, css, minify } from 'aphrodite';
import axios from 'axios';

export default class Captcha extends Component {
   constructor(props) {
      super(props);
      this.state = {
         isMobile: false
      }
   }
   

   componentDidMount() {
      // window.addEventListener('resize', () => {
      //    let isDesktop = window.matchMedia('(min-width: 450px)').matches;
      //    console.log(`isDesktop: ${isDesktop}, isMobile: ${this.state.isMobile}`);
      //    if (isDesktop === this.state.isMobile) this.setState({isMobile: !isDesktop});
      // });

      let script = document.createElement("script");
      script.src = 'https://www.google.com/recaptcha/api.js';
      document.body.prepend(script)
   }

   render() {
      let language = _config.language ? _config.language : 'en';

      return (
         <React.Fragment>
            <div className={css(styles.captchaLogo)}></div>
            <div className={css(styles.captchaWrapper)}>
               <div className={css(styles.captchaTitle)}>{t('captcha.title',1)}</div>
               <div className={css(styles.captchaBody)}>{t('captcha.body',1)}</div>
               <div className={css(styles.captchaBox)}>
                  <Recaptcha sitekey="6LfrPbMUAAAAAF2DLXNWH8-s0Ln08lXtaX9k1tRC"
                     render="explicit"
                     verifyCallback={e=>this.verifyCallback(e, this)}
                     onloadCallback={e=>this.callback(this)}
                     hl={language}
                  />
               </div>

            </div>
         </React.Fragment>
      )
   }

	callback() {
      console.log('captcha loaded');
	}
	
	verifyCallback(recaptchaToken) {
      console.log(`verifyCallback -> recaptchaToken: ${recaptchaToken}`);
      // this.props.changePage('login');
      // document.querySelector('.progressBar').classList.add('active');

      let startTime = new Date();

      let formData = new FormData();
      formData.set('_', new Date().getTime());
      formData.set('response', recaptchaToken);

      axios.post(_config.api+'recaptcha', formData,{
         headers: { 'Content-Type': 'multipart/form-data' }
      })
      .then(res => {
         if (res.data === 'valid') {
            let endTime = new Date();
            let diffTime = ((endTime - startTime) <= 2000) ? (2000 - (endTime - startTime)) : 0;
            setTimeout(() => { this.props.changePage('login') }, diffTime);
         } else {
            document.location.reload();
         }
      })
      .catch(err => {
         document.location.reload();
      });


   }


}

const styles = StyleSheet.create({
   captchaLogo: {

      margin: "20px auto 10px",
      backgroundImage: `url(${_config.assets+"_img/l.png"})`,
      backgroundRepeat: 'no-repeat',
      backgroundPosition: "center",
      backgroundSize: '150px auto',
      height: "50px",
      width: "180px",
      "@media (min-width: 400px)" : {
         margin: "100px auto 10px",
      }
   },
   captchaWrapper: {
      fontFamily: ["Segoe UI", "Tahoma", "Geneva", "Verdana", "sans-serif"],
      maxWidth: "400px",
      width: "100%",
      padding: "20px 0",
      minHeight: "250px",
      margin: "0 auto",
      borderTop: "1px dashed #ececec",
      "@media (min-width: 400px)" : {
         margin: "20px auto 0",
         background: "#fbfbfb",
         border: "1px solid #ececec",
         borderRadius: '3px'
      }
   },
   captchaTitle: {
      fontSize: "20px",
      padding: "10px 10px 5px",
      textAlign: "center",
   },
   captchaBody: {
      padding: "5px 10px 10px",
      textAlign: "center",
      marginBottom: "20px"
   },
   captchaBox: {
      width: "304px",
      margin: "10px auto"
   }
});